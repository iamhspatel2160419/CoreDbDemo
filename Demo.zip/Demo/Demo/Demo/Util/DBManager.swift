//
//  DBManager.swift
//  Demo
//
//  Created by Apple on 21/11/20.
//

import Foundation
import UIKit
import CoreData

class DBManager
{
    static let sharedManager = DBManager()
    
    static var appDelegate: AppDelegate
    {
            if Thread.isMainThread {
                return UIApplication.shared.delegate as! AppDelegate
            }

            var appDelegate: AppDelegate!
            DispatchQueue.main.sync {
                appDelegate = UIApplication.shared.delegate as! AppDelegate
            }
            return appDelegate
        }
    
    
    
    init()
    {
        
    }
    
    var dictParams : NSDictionary!
    func insertIntoTable(_ tableName:String,
                         dictInsertData:NSDictionary)
    {
     
        let appDelegate = DBManager.appDelegate
        let managedContext = appDelegate.managedObjectContext
        let managedObject = NSEntityDescription.insertNewObject(forEntityName: tableName,
                                                                into: managedContext)
        
        let entity = managedObject.entity
        dictParams = entity.attributesByName as NSDictionary
       
        for(tempKey,_) in dictParams
        {
           var entityObject:AnyObject
            let key = tempKey
            if let val = dictInsertData.object(forKey: key)
            {
                entityObject = val as AnyObject
                
                if entityObject is NSNull
                {
                    
                }
                else
                {
                    managedObject.setValue(entityObject, forKey: key as! String )
                }
            }
            else if dictInsertData[key] != nil
            {
                entityObject = dictInsertData.object(forKey: key)! as AnyObject
                
                if entityObject is NSNull
                {
                    
                }
                else
                {
                    managedObject.setValue(entityObject, forKey: key as! String )
                }
            }
         }
        do
        {
            try DBManager.appDelegate.managedObjectContext.save()
        }
        catch let error as NSError
        {
            print(" core data error \(error.userInfo)")
        }
    }
    func retrieveData(completion : (_ result : NSArray) -> Void)
    {
        let appDelegate = DBManager.appDelegate
        let managedContext = appDelegate.managedObjectContext
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "User")
        do {
            let result = try managedContext.fetch(fetchRequest)
            completion(result as NSArray)
        } catch {

            print("Failed")
        }
    }
   
    func deleteAllData(_ entity: String)
    {
        let appDelegate = DBManager.appDelegate
        let managedContext = appDelegate.managedObjectContext
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: entity)
        
        // let fetchRequest = NSFetchRequest(entityName: entity)
        fetchRequest.returnsObjectsAsFaults = false
        
        do
        {
            let results = try managedContext.fetch(fetchRequest)
            
            for manageObjects in results {
                appDelegate.managedObjectContext.delete(manageObjects as! NSManagedObject)
                try appDelegate.managedObjectContext.save()
                //print(manageObjects)
            }
            
        } catch let error as NSError {
            print("Detele all data in \(entity) error : \(error) \(error.userInfo)")
        }
    }
    func deleteSelectedId(_ entity: String,strPredicate:String)
    {
        let appDelegate = DBManager.appDelegate
        let managedContext = appDelegate.managedObjectContext
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: entity)
        
        // let fetchRequest = NSFetchRequest(entityName: entity)
        if !strPredicate.isEmpty
        {
            fetchRequest.predicate = NSPredicate(format: strPredicate)
            
        }
        do
        {
            let results = try managedContext.fetch(fetchRequest)
            fetchRequest.returnsObjectsAsFaults = false
            
            for manageObjects in results {
                appDelegate.managedObjectContext.delete(manageObjects as! NSManagedObject)
                try appDelegate.managedObjectContext.save()
                //print(manageObjects)
            }
            
        } catch let error as NSError
        {
            print("Detele all data in \(entity) error : \(error) \(error.userInfo)")
        }
    }
    
    
}
extension String {
    func capitalizingFirstLetter() -> String {
      return prefix(1).uppercased() + self.lowercased().dropFirst()
    }

    mutating func capitalizeFirstLetter() {
      self = self.capitalizingFirstLetter()
    }
}
