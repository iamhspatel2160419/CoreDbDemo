//
//  HomeViewController.swift
//  Demo
//
//  Created by Apple on 21/11/20.
//

import UIKit
import Kingfisher
class HomeViewController: UITableViewController
{
    var indicator = UIActivityIndicatorView()
    var model_ = [User]()
    var filteredModel_ = [User]()
    let searchController = UISearchController(searchResultsController: nil)
    var isSearchBarEmpty: Bool {
      return searchController.searchBar.text?.isEmpty ?? true
    }
    var isFiltering: Bool {
      return searchController.isActive && !isSearchBarEmpty
    }
    
    func filterContentForSearchText(_ searchText: String)
    {
        DispatchQueue.global(qos: .background).async
        {
            let value = searchText.lowercased()
            self.filteredModel_ = self.model_.filter { user  -> Bool in
                if let modelValue = user.full_name
                {
                    return modelValue.lowercased().contains(value)
                }
                return false
            }
            DispatchQueue.main.async {
                self.tableView.reloadData()
            }
        }
    }
    override func viewDidAppear(_ animated: Bool) {
        definesPresentationContext = true
    }
   
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        // 1
        searchController.searchResultsUpdater = self
        // 2
        searchController.obscuresBackgroundDuringPresentation = false
        // 3
        searchController.searchBar.placeholder = "Search Users"
        // 4
        navigationItem.hidesSearchBarWhenScrolling = true

        navigationItem.searchController = searchController
        // 5
        definesPresentationContext = true
        
        self.refreshControl  = UIRefreshControl()
        self.refreshControl?.tintColor = .red
        self.refreshControl?.addTarget(self, action:#selector(refreshList) , for: UIControl.Event.valueChanged)
        tableView.addSubview(refreshControl!)
        
        self.CallApi()
        
        
    }
   
    func activityIndicator() {
        indicator = UIActivityIndicatorView(frame: CGRect(x: 0, y: 0, width: 100, height: 100))
        indicator.style = UIActivityIndicatorView.Style.gray
        indicator.backgroundColor = UIColor.clear
        indicator.center = self.view.center
        self.view.addSubview(indicator)
    }
    @objc func refreshList()
    {
        if isFiltering
        {
            self.refreshControl?.endRefreshing()
        }
        else
        {
            model_.removeAll()
            filteredModel_.removeAll()
            model_ = [User]()
            filteredModel_ = [User]()
            DBManager.sharedManager.deleteAllData("User")
            self.tableView.reloadData()
            DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
                self.CallApi()
            }
        }
        
    }
    func parseJSONFromData(jsonData: NSData?) -> [String: AnyObject]?
    {
        if let data = jsonData{
            do{
                let jsonDictionary = try JSONSerialization.jsonObject(with: data as Data, options: JSONSerialization.ReadingOptions.mutableContainers) as! [String: AnyObject]
                
                return jsonDictionary
                
            } catch let error as NSError {
                print("Error processing JSON Data \(error.description)")
            }
        }
        return nil
    }
    
    
    
    let tempDict = NSMutableDictionary()
    func CallApi()
    {
        self.refreshControl?.endRefreshing()
        activityIndicator()
        indicator.startAnimating()
        indicator.backgroundColor = UIColor.white
        
        guard let url = NSURL(string: "https://beta3.moontechnolabs.com/app_practical_api/public/api/user") else { return  }
        let manager = ApiManager(url: url)
        
        
        model_ = [User]()
        filteredModel_ = [User]()
        
        manager.downloadData(completion:
                                { (data) in
                                    guard let json = self.parseJSONFromData(jsonData: data)
                                    else
                                    {
                                        return
                                    }
                                    DBManager.sharedManager.deleteAllData("User")
                                    let model = Model(object: json)
                                    if let list = model.getAllData()
                                    {
                                        
                                        for i in list
                                        {
                                            
                                            self.tempDict.setValue(i.profilePicURL , forKey: "profile_pic_url")
                                            self.tempDict.setValue(i.id, forKey: "id")
                                            self.tempDict.setValue(i.email, forKey: "email")
                                            self.tempDict.setValue(i.profilePic, forKey: "profile_pic")
                                            self.tempDict.setValue(i.phone, forKey: "phone")
                                            self.tempDict.setValue(i.address, forKey: "address")
                                            self.tempDict.setValue(i.dob, forKey: "dob")
                                            self.tempDict.setValue(i.gender, forKey: "gender")
                                            self.tempDict.setValue(i.designation, forKey: "designation")
                                            self.tempDict.setValue(i.salary, forKey: "salary")
                                            self.tempDict.setValue(i.createdAt, forKey: "created_at")
                                            self.tempDict.setValue(i.updatedAt, forKey: "updated_at")
                                            self.tempDict.setValue(i.fullName, forKey: "full_name")
                                            
                                            DBManager.sharedManager.insertIntoTable("User",
                                                                                    dictInsertData: self.tempDict)
                                        }
                                    }
                                    
                                    
                                    DBManager.sharedManager.retrieveData { (data) in
                                        
                                        if data.count>0
                                        {
                                            for i in data{
                                                
                                                let object = i as! User
                                                self.model_.append(object)
                                            }
                                        }
                                        DispatchQueue.main.async {
                                            self.tableView.reloadData()
                                            
                                            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5)
                                            {
                                                self.indicator.stopAnimating()
                                                self.indicator.hidesWhenStopped = true
                                            }
                                            
                                        }
                                       
                                    }
                              })
        
    }
    
    // MARK: - Table view data source
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        
        if isFiltering {
            return filteredModel_.count > 0 ? filteredModel_.count : 0
          }
            
        return model_.count > 0 ? model_.count : 0
    }
    
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if let cell = tableView.dequeueReusableCell(withIdentifier: "CustomCell", for: indexPath) as? CustomCell
        
        {
            
            let _model : User
            if isFiltering {
                _model = filteredModel_[indexPath.row]
              } else {
                _model = model_[indexPath.row]
              }
            cell.lblUserName.text = _model.full_name
            cell.lblUserDesc.text = _model.designation
            cell.lblDate.text = _model.created_at
            
            let profileUrl = _model.profile_pic_url ?? ""
            
            if !profileUrl.isEmpty
            {
                let url = URL(string: profileUrl)
                cell.userImageView.kf.setImage(with: url)
            }
            cell.backgroundColor = UIColor.white
            cell.userImageView.layer.cornerRadius = 50;
            cell.userImageView.clipsToBounds = true;

            return cell
        }
        
        return UITableViewCell()
    }
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return  UITableView.automaticDimension
    }
    
    
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }

    override func tableView(_ tableView: UITableView,
                   commit editingStyle: UITableViewCell.EditingStyle,
                   forRowAt indexPath: IndexPath)
    {
        if (editingStyle == .delete) {
            
            if isFiltering {
                let id = filteredModel_[indexPath.row].id
                DBManager.sharedManager.deleteSelectedId("User",strPredicate:"id=\(id)")
                
                self.filteredModel_.remove(at: indexPath.row)
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.5)
                {
                    self.tableView.reloadData()
                }
            }
            else
            {
                let id = model_[indexPath.row].id
                DBManager.sharedManager.deleteSelectedId("User",strPredicate:"id=\(id)")
                self.model_.remove(at: indexPath.row)
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.5)
                {
                    self.tableView.reloadData()
                }
            }
            
       }
    }
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        if isFiltering
        {
            let object = filteredModel_[indexPath.row]
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            let _DetailViewController = storyboard.instantiateViewController(withIdentifier: "DetailViewController") as! DetailViewController
            _DetailViewController.user = object
            self.navigationController?.pushViewController(_DetailViewController, animated: true)
        }
        else
        {
            let object = model_[indexPath.row]
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            let _DetailViewController = storyboard.instantiateViewController(withIdentifier: "DetailViewController") as! DetailViewController
            _DetailViewController.user = object
            self.navigationController?.pushViewController(_DetailViewController, animated: true)
        }
    }
    
  
    
}
extension HomeViewController: UISearchResultsUpdating {
  func updateSearchResults(for searchController: UISearchController) {
    
    guard let text = searchController.searchBar.text else { return }
    filterContentForSearchText(text)
  }
}
