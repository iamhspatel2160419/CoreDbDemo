//
//  DetailViewController.swift
//  Demo
//
//  Created by Apple on 22/11/20.
//

import UIKit

class DetailViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {

    let arrTitle = ["Full Name","Email","Phone number","Address","BirthDate","Gender","Designation","Salary"]
    var arrValue:[String] = []
    var user:User?
    var imageUrl = ""
    @IBOutlet weak var tableview: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()

        tableview.delegate = self
        tableview.dataSource = self
        // Do any additional setup after loading the view.
        if let user = user
        {
            imageUrl = user.profile_pic_url ?? "-"
            
            arrValue.append(user.full_name ?? "-")
            arrValue.append(user.email ?? "-")
            arrValue.append(user.phone ?? "-")
            arrValue.append(user.address ?? "-")
            arrValue.append(user.dob ?? "-")
            arrValue.append(user.gender ?? "-")
            arrValue.append(user.designation ?? "-")
            arrValue.append("\(user.salary)")
            tableview.reloadData()
        }
    }
    override func viewWillAppear(_ animated: Bool)
    {
        self.title = "User Detail"
        
    }
    func numberOfSections(in tableView: UITableView) -> Int
    {
        return 2
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        if section == 0
        {
            return 1
        }
        return arrTitle.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        if indexPath.section == 0
        {
            var cellIdentifier : String! = ""
            cellIdentifier = "CustomCellHeader"
            let customCellHeader:CustomCell = tableView.dequeueReusableCell(withIdentifier:cellIdentifier) as! CustomCell
            let url = URL(string: imageUrl)
            customCellHeader.userImageViewDetailView.layer.cornerRadius = customCellHeader.userImageViewDetailView.frame.size.width / 2;
            customCellHeader.userImageViewDetailView.clipsToBounds = true;
            customCellHeader.userImageViewDetailView.kf.setImage(with: url)
            return customCellHeader
        }
        else if indexPath.section == 1
        {
            var cellIdentifier : String! = ""
            cellIdentifier = "CustomCellDetail"
            let customCellDetail:CustomCell = tableView.dequeueReusableCell(withIdentifier:cellIdentifier) as! CustomCell
            customCellDetail.lblTitleDetailView.text = arrTitle[indexPath.row]
            customCellDetail.lblValueNameDetailView.text = arrValue[indexPath.row]
            return customCellDetail
        }
        return UITableViewCell()
     }

    func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat
    {
        if indexPath.section == 0
        {
            return 132
        }
        return UITableView.automaticDimension
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat
    {
        if indexPath.section == 0
        {
            return 132
        }
        return UITableView.automaticDimension
    }
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat
    {
        if section == 0
        {
            return 1
        }
        else
        {
            return 16
        }
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView?
    {
        let mainView = UIView()
        if section == 0
        {
            return mainView
        }
        else
        {
            let customView2 = UIView(frame: CGRect(x: 0, y: 0.0, width: self.view.frame.size.width, height: 16.0))
            customView2.backgroundColor = UIColor.clear
            mainView.addSubview(customView2)
            
        }
        return mainView
    }
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView?
    {
        
        let customView = UIView(frame: CGRect(x: 0, y: 0, width: self.view.frame.size.width, height: 2.0))
            customView.backgroundColor = UIColor( red: CGFloat(203/255.0), green: CGFloat(203/255.0), blue: CGFloat(206/255.0), alpha: CGFloat(1.0) )
            return customView
        
    }
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
  
        return 2.0
    }
    
}
