//
//  CustomCell.swift
//  Demo
//
//  Created by Apple on 21/11/20.
//

import UIKit

class CustomCell: UITableViewCell {

    @IBOutlet weak var lblUserDesc: UILabel!
    @IBOutlet weak var userImageView: UIImageView!
    @IBOutlet weak var lblUserName: UILabel!
    @IBOutlet weak var lblDate: UILabel!
    
    // table header View
    @IBOutlet weak var userImageViewDetailView: UIImageView!
    
    
    @IBOutlet weak var lblTitleDetailView: UILabel!
    @IBOutlet weak var lblValueNameDetailView: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
