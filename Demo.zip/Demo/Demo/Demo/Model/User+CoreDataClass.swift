//
//  User+CoreDataClass.swift
//  Demo
//
//  Created by Apple on 21/11/20.
//
//

import Foundation
import CoreData

@objc(User)
public class User: NSManagedObject {

}
