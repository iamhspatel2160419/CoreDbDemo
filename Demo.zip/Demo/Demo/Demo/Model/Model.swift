import Foundation

// MARK: - Model
class Model {
    var data = [Datum]()
    var list:[[String:AnyObject]]!

    init(object:[String:AnyObject])
    {
        if let list = object["data"] as? [[String:AnyObject]]
        {
            self.list = list
            
        }
    }
    func getAllData() -> [Datum]?
    {
        for object in list
        {
            let datum_ = Datum(profilePicURL: object["profile_pic_url"] as? String,
                               id: object["id"] as! Int32,
                               fullName: object["full_name"] as? String,
                               email: object["email"] as? String,
                               profilePic: object["profile_pic"] as? String,
                               phone: object["phone"] as? String,
                               address: object["address"] as? String,
                               dob: object["dob"] as? String,
                               gender: object["gender"] as? String,
                               designation: object["designation"] as? String,
                               salary: object["salary"] as? Int32,
                               createdAt: object["created_at"] as? String,
                               updatedAt: object["updated_at"] as? String)
            self.data.append(datum_)
            
       }
       return self.data
    }
}


// MARK: - Datum
class Datum {
    let profilePicURL: String
    let id: Int32
    let fullName: String?
    let email, profilePic: String
    let phone, address, dob: String?
    let gender: String
    let designation: String
    let salary: Int32?
    let createdAt, updatedAt: String

    init(profilePicURL: String?, id: Int32, fullName: String?, email: String?, profilePic: String?, phone: String?, address: String?, dob: String?, gender: String?, designation: String?, salary: Int32?, createdAt: String?, updatedAt: String?) {
        self.profilePicURL = profilePicURL ?? ""
        self.id = id
        self.fullName = fullName ?? ""
        self.email = email ?? ""
        self.profilePic = profilePic ?? ""
        self.phone = phone ?? ""
        self.address = address ?? ""
        self.dob = dob ?? ""
        self.gender = gender ?? ""
        self.designation = designation ?? ""
        self.salary = salary ?? 0
        self.createdAt = createdAt ?? ""
        self.updatedAt = updatedAt ?? ""
    }
}

