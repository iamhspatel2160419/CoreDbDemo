//
//  User+CoreDataProperties.swift
//  Demo
//
//  Created by Apple on 21/11/20.
//
//

import Foundation
import CoreData


extension User {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<User> {
        return NSFetchRequest<User>(entityName: "User")
    }

    @NSManaged public var profile_pic_url: String?
    @NSManaged public var id: Int32
    @NSManaged public var email: String?
    @NSManaged public var profile_pic: String?
    @NSManaged public var phone: String?
    @NSManaged public var address: String?
    @NSManaged public var dob: String?
    @NSManaged public var gender: String?
    @NSManaged public var designation: String?
    @NSManaged public var salary: Int32
    @NSManaged public var created_at: String?
    @NSManaged public var updated_at: String?
    @NSManaged public var full_name: String?

}

extension User : Identifiable {

}
